from django.db import models
from django.contrib.gis.db import models

# Create your models here.
# Importamos tambien de 'gis.db' y no solo de 'db' porque usamos geometrías espaciales

class Parques(models.Model):
    nombre = models.CharField(max_length=100, null=True, blank=True)
    area_hectareas = models.FloatField(null=True, blank=True)
    tiene_zona_infantil = models.BooleanField(default=False, null=True, blank=True)
    horario_cierre = models.TimeField(null=True, blank=True)
    tipo_mantenimiento = models.CharField(max_length=50, null=True, blank=True)
    geom = models.PolygonField(srid=25830)

class Contenedores(models.Model):
    tipo_residuo = models.CharField(max_length=50, null=True, blank=True)
    capacidad_litros = models.FloatField(null=True, blank=True)
    fecha_ultima_recogida = models.DateField(null=True, blank=True)
    estado_conservacion = models.CharField(max_length=50, null=True, blank=True)
    barrio = models.CharField(max_length=100, null=True, blank=True)
    geom = models.PointField(srid=25830)

class CarrilesBici(models.Model):
    nombre_calle = models.CharField(max_length=100, null=True, blank=True)
    longitud_metros = models.FloatField(null=True, blank=True)
    tipo_pavimento = models.CharField(max_length=50, null=True, blank=True)
    sentido_unico = models.BooleanField(default=False, null=True, blank=True)
    anyo_construccion = models.IntegerField(null=True, blank=True)
    geom = models.LineStringField(srid=25830)