from smartcity_app.models import Parques
from django.forms.models import model_to_dict

class ParquesDjango:
    
    def insert(self, d):
        try:
            # En Django, instanciamos modelo vacio y rellenamos
            b = Parques()
            b.nombre = d.get('nombre')
            b.area_hectareas = d.get('area_hectareas')
            b.tiene_zona_infantil = d.get('tiene_zona_infantil')
            b.horario_cierre = d.get('horario_cierre')
            b.tipo_mantenimiento = d.get('tipo_mantenimiento')
            b.geom = d.get('geom') # Geodjango entiende el texto de coordenadas (WKT) automaticamente
            
            # Guardamos en bdd
            b.save()
            
            return {'ok': True, 'message': 'Parque insertado con Django', 'data': [{'id': b.id}]}
        except Exception as e:
            return {'ok': False, 'message': str(e), 'data': []}

    def update(self, d):
        try:
            id_row = d['id']
            # Buscamos objeto por su ID
            b = list(Parques.objects.filter(id=id_row))[0]
            
            # Actualizamos solo lo que nos pasen en el diccionario
            if 'nombre' in d: b.nombre = d['nombre']
            if 'area_hectareas' in d: b.area_hectareas = d['area_hectareas']
            if 'tiene_zona_infantil' in d: b.tiene_zona_infantil = d['tiene_zona_infantil']
            if 'horario_cierre' in d: b.horario_cierre = d['horario_cierre']
            if 'tipo_mantenimiento' in d: b.tipo_mantenimiento = d['tipo_mantenimiento']
            if 'geom' in d: b.geom = d['geom']
            
            b.save()
            return {'ok': True, 'message': 'Parque actualizado con Django', 'data': [{'rows_updated': 1}]}
        except Exception as e:
            return {'ok': False, 'message': str(e), 'data': []}

    def delete(self, d):
        try:
            id_row = d['id']
            b = list(Parques.objects.filter(id=id_row))[0]
            b.delete()
            return {'ok': True, 'message': 'Parque borrado con Django', 'data': [{'rows_deleted': 1}]}
        except Exception as e:
            return {'ok': False, 'message': str(e), 'data': []}

    def selectAsDicts(self, d):
        try:
            id_row = d['id']
            lista = list(Parques.objects.filter(id=id_row))
            
            if len(lista) == 0:
                return {'ok': False, 'message': f"El parque id {id_row} no existe", 'data': []}
                
            b = lista[0]
            
            # Usamos funcion de Django para convertir el objeto a diccionario
            dic = model_to_dict(b)
            
            # Convertimos la geometria a texto legible antes de devolverla
            if dic.get('geom'):
                dic['geom'] = dic['geom'].wkt
                
            return {'ok': True, 'message': 'Parque recuperado con Django', 'data': [dic]}
        except Exception as e:
            return {'ok': False, 'message': str(e), 'data': []}

    def selectAsTuples(self, d):
        try:
            id_row = d['id']
            lista = list(Parques.objects.filter(id=id_row))
            
            if len(lista) == 0:
                return {'ok': False, 'message': f"El parque id {id_row} no existe", 'data': []}
                
            b = lista[0]
            geom_text = b.geom.wkt if b.geom else None
            
            # Construimos la tupla manualment
            tup = (b.id, b.nombre, b.area_hectareas, b.tiene_zona_infantil, b.horario_cierre, b.tipo_mantenimiento, geom_text)
            
            return {'ok': True, 'message': 'Parque recuperado en tupla con Django', 'data': [tup]}
        except Exception as e:
            return {'ok': False, 'message': str(e), 'data': []}