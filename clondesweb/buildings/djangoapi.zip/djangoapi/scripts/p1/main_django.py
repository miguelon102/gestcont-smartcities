from scripts.p1.parques.parques_django import ParquesDjango

def run(*args):
    # args recibe los parametros que le pasemos por la consola
    if len(args) != 2:
        print("Error: Necesitas dar dos parametros: tableName y functionName.")
        return

    tableName = args[0]
    functionName = args[1]

    if tableName not in ["parques"]:
        print("Error: Las tablas disponibles (en Django) son parques")
        return
    
    if functionName not in ["insert", "select", "selectAsDict", "update", "delete"]:
        print("Error: Las funciones disponibles son insert, select, selectAsDict, delete o update")
        return

    # Datos de prueba para ORM de Django
    d_parque = {
        'nombre': 'Parque Django Prueba',
        'area_hectareas': 20.5,
        'tiene_zona_infantil': True,
        'horario_cierre': '20:00:00',
        'tipo_mantenimiento': 'Mensual',
        'geom': 'POLYGON((0 0, 50 0, 50 50, 0 50, 0 0))'
    }

    if tableName == "parques":
        b = ParquesDjango()
        d = d_parque
        
        # Ejecutamos la funcion elegida
        if functionName == "insert":
            print(b.insert(d))
        elif functionName == "select":
            print(b.selectAsTuples({'id': 1})) # Suponemos que leeremos el ID 1
        elif functionName == "selectAsDict":
            print(b.selectAsDicts({'id': 1}))
        elif functionName == "update":
            d['id'] = 1 # Añadimos el ID al diccionario para el update
            d['nombre'] = 'Parque Django ACTUALIZADO'
            print(b.update(d))
        elif functionName == "delete":
            print(b.delete({'id': 1}))